## Installation

Install dependencies:
```bash
cd TR-Project
uv venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
uv pip install -r requirements.txt

Select the kernel "TR-Project(Python 3.13.2) .venv/bin/python" in jupyter notebook
```

## There are three jupyter notebooks which corresponding to three questions in the project-note

1.  data_analysis_q1.ipynb   :    Data Analysis and Visualization
2.  model_development_q2.ipynb  : Model developments and experiment
    
    (1) Benchmark Model:   TFIDF + Decision Tree Based Model

    (2) Transformers-Based Encoder model (MordenBERT)

    Benchmark model is lightweight and don't need GPU
    However, when training transformer based model, GPU is highly recommended to speed up model training and inference. 

    In the notebook,  I only set max_context_length=512 for demonstration purpose.  For longer context length and different model sizes,  please run "bash run_train.sh" in the terminal.  I trained the MordenBERT model in RunPod GPU cloud https://console.runpod.io/deploy using L4 machine with multiple GPUs

3.  Addition_experiment_q3.ipynb  : Additional experiments for next steps

    This notebook walks you through building a summarization pipeline and the retrieval component of a RAG workflow, enabling large language models to process information more efficiently. Note: You’ll need an OpenAI API key to run the notebook, as it calls the GPT-4o model.


4.  Data Science Challenge Report.pdf

    This report provides a comprehensive information of data analysis, documents the full model-development process, and describes additional experiments to inform the next steps.
    

```

